import {
  MENU_BACK_BUTTON_PRIORITY,
  OVERLAY_BACK_BUTTON_PRIORITY,
  blockHardwareBackButton,
  shouldUseCloseWatcher,
  startHardwareBackButton
} from "./chunk-O62FXVV6.js";
import "./chunk-LCMILTBF.js";
import "./chunk-6MP44WRP.js";
import "./chunk-QHQP2P2Z.js";
export {
  MENU_BACK_BUTTON_PRIORITY,
  OVERLAY_BACK_BUTTON_PRIORITY,
  blockHardwareBackButton,
  shouldUseCloseWatcher,
  startHardwareBackButton
};
