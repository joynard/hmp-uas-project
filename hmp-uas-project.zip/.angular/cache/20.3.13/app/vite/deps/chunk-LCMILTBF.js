// node_modules/@ionic/core/dist/esm/index-ZjP4CjeZ.js
var win = typeof window !== "undefined" ? window : void 0;
var doc = typeof document !== "undefined" ? document : void 0;

export {
  win,
  doc
};
/*! Bundled license information:

@ionic/core/dist/esm/index-ZjP4CjeZ.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
//# sourceMappingURL=chunk-LCMILTBF.js.map
